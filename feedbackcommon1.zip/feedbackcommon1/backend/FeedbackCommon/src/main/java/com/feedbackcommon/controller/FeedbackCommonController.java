package com.feedbackcommon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.feedbackcommon.bean.FeedbackCommon;
import com.feedbackcommon.service.FeedbackCommonService;



@RestController
public class FeedbackCommonController {
	
	@Autowired
	FeedbackCommonService service;
	
	@PostMapping("/add")
	public void addMessage(@RequestBody FeedbackCommon feedback )
	{
		service.addMessage(feedback);
	}
	
	public List<FeedbackCommon> getMessages()
	{
		return service.getMessages();
		
	}
}

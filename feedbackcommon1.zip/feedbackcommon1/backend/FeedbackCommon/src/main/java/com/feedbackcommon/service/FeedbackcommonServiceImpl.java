package com.feedbackcommon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feedbackcommon.bean.FeedbackCommon;
import com.feedbackcommon.dao.FeedbackCommonDao;

@Service
public class FeedbackcommonServiceImpl implements FeedbackCommonService{
	
	@Autowired
	FeedbackCommonDao feedbackDao;

	@Override
	public void addMessage(FeedbackCommon feedback) {
		feedbackDao.save(feedback);
		
	}

	@Override
	public List<FeedbackCommon> getMessages() {
		
		return feedbackDao.findAll();
	}

}

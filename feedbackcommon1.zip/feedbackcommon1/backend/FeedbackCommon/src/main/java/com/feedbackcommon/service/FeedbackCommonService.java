package com.feedbackcommon.service;

import java.util.List;

import com.feedbackcommon.bean.FeedbackCommon;

public interface FeedbackCommonService {

	void addMessage(FeedbackCommon feedback);

	List<FeedbackCommon> getMessages();

}

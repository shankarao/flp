package com.feedbackcommon.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.feedbackcommon.bean.FeedbackCommon;

@Repository
public interface FeedbackCommonDao  extends JpaRepository<FeedbackCommon, Integer>{

}

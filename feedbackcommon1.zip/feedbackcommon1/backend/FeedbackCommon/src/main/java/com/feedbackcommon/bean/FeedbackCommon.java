package com.feedbackcommon.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "msg",allocationSize = 1,initialValue = 10001)
public class FeedbackCommon {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO,generator = "msg")
	private int messageId;
	private int merchantId;
	private int customerId;
	private String message;
	public FeedbackCommon() {
		super();
	}
	public FeedbackCommon(int messageId, int merchantId, int customerId, String message) {
		super();
		this.messageId = messageId;
		this.merchantId = merchantId;
		this.customerId = customerId;
		this.message = message;
	}
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "FeedbackCommon [messageId=" + messageId + ", merchantId=" + merchantId + ", customerId=" + customerId
				+ ", message=" + message + "]";
	}
	
	

}

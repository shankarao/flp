import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerFeedbackComponent } from './FeedbackCommon/customer-feedback/customer-feedback.component';
import { MerchentResponseComponent } from './FeedbackCommon/merchent-response/merchent-response.component';


const routes: Routes = [
  {path:"customer",component:CustomerFeedbackComponent},
  {path:"merchant",component:MerchentResponseComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Injectable } from '@angular/core';
import {HttpClient}from '@angular/common/http';
import { Message } from './Message';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FeedbackcommonServiceService {
  
  message:Message[]
  constructor(private http:HttpClient) { 
    this.populateChat().subscribe(data=>this.message=data,error=>console.log(error),);
  }
  
  populateChat():Observable<Message[]>{
    return this.http.get<Message[]>("../../assets/messages.json");
    
  }
      add(msg){
        console.log(msg);
      return this.message.push(msg);
      }
      get():Message[] {
        return this.message;
      }

}

import { Component, OnInit } from '@angular/core';
import { Message } from '../Message';
import { FeedbackcommonServiceService } from '../feedbackcommon-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-merchent-response',
  templateUrl: './merchent-response.component.html',
  styleUrls: ['./merchent-response.component.css']
})
export class MerchentResponseComponent implements OnInit {
message:Message[];
  constructor(private service:FeedbackcommonServiceService,private router:Router) { }

  ngOnInit() {
   this.message= this.service.get();
  }
  onSubmit(value)
  {

    this.service.add(value);
    this.router.navigate(['/customer']);
  }
}

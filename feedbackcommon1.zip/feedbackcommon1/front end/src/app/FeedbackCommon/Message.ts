export interface Message
{
    message:String
}
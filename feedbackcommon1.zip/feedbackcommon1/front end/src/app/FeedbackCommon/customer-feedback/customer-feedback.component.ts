import { Component, OnInit } from '@angular/core';
import { Message } from '../Message';
import { FeedbackcommonServiceService } from '../feedbackcommon-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-feedback',
  templateUrl: './customer-feedback.component.html',
  styleUrls: ['./customer-feedback.component.css']
})
export class CustomerFeedbackComponent implements OnInit {
message:Message[];
  constructor(private service:FeedbackcommonServiceService,private router:Router) { }

  ngOnInit() {
    this.message=this.service.get();
  }
  onSubmit(value)
  {
    this.service.add(value);
    this.router.navigate(['/merchant']);
  }
}
